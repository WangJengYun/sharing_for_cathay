from ._base import BaseEC
import pandas as pd
from sklearn.cluster import DBSCAN

class DBSCANModel(BaseEC):

    def __init__(self):

        super().__init__()
        self.empty_ec_model = DBSCAN
        self.noise_value = None

    def fit(
        self,
        eps=0.5,
        min_samples=5,
        metric='euclidean',
        metric_params=None,
        algorithm='auto',
        leaf_size=30,
        noise_value = -1,
        p=None,
        n_jobs=None
    ):
        self.noise_value = noise_value
        self.ec_model = self.empty_ec_model(
            eps = eps,
            min_samples = min_samples,
            metric = metric,
            metric_params = metric_params,
            algorithm = algorithm,
            leaf_size = leaf_size,
            p = p,
            n_jobs = n_jobs
        )
        self.ec_model.fit(self.embeddings)

    def predict(self, input_embeddings = None):
        if input_embeddings is None:
            output_label = self.ec_model.fit_predict(self.embeddings)
            output_label[output_label == -1] = self.noise_value
            return output_label

        if input_embeddings is not None:
            output_label = self.ec_model.labels_
            output_label[output_label == -1] = self.noise_value
            return output_label
        return None

if __name__ == '__main__':
    from sentence_transformers import SentenceTransformer
    words = ['交易','交易市場','天氣','下雨','金融','風險','詐貸','你好','銀行','銀行','信用卡','風險']
    data = pd.DataFrame({'id':range(len(words)), 'event':words})

    model = SentenceTransformer('/Users/mac/Desktop/distiluse-base-multilingual-cased-v1')
    embeddings = model.encode(data['event'].tolist(), show_progress_bar = True)
    data['embeddings'] = embeddings.tolist()


    EC = DBSCANModel()
    EC.set_data(data, index_col='id', embedding_col= 'embeddings')
    EC.fit(eps = 0.9256)
    # output_label = EC.predict()
    result = EC.transform(
        data,
        index_col = 'id',
        embedding_col = 'embeddings',
        cluster_col = 'CLUSTER',
        cluster_name = 'word'
    )
