from ._base import BaseEC
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

class SimilarityCulstering(BaseEC):
    def __init__(self):
        super(SimilarityCulstering, self).__init__()

        self.threshold = None
        self.other_class = None
        self.data_idx = None
        self.noise_value = None

    @staticmethod
    def _convert_to_similarity_pairs(
        input_x,
        input_y = None,
        threshold = 0.75,
        output_head_name:str = 'head',
        output_tail_name:str = 'tail'
    ):

        if input_y is None:
            similarity_table = pd.DataFrame(cosine_similarity(input_x)).reset_index()
        else:
            similarity_table = pd.DataFrame(cosine_similarity(input_x,input_y)).reset_index()
        similarity_table = pd.melt(similarity_table, id_vars = ['index'])

        similarity_table = similarity_table[
            ~(similarity_table['index'] == similarity_table['variable'])
        ]
        similarity_table = similarity_table[similarity_table['value'] >= threshold]

        similarity_table = similarity_table.rename(
            columns = {'index':output_head_name, 'variable':output_tail_name}
        )

        return similarity_table

    def fit(self, threshold, noise_value  = -1):
        self.threshold = threshold
        self.noise_value = noise_value

        similarity_table = self._convert_to_similarity_pairs(
            self.embeddings,
            threshold = self.threshold,
            output_head_name = 'head',
            output_tail_name = 'tail',
        )

        head_idx = similarity_table['head'].tolist()
        tail_idx = similarity_table['tail'].tolist()

        cluster_set = []
        head = None
        tail = None
        for head, tail in zip(head_idx, tail_idx):
            is_exits = np.array(
                list(
                    map(
                        lambda single_set: (head in single_set) or (tail in single_set),\
                        cluster_set
                    )
                )
            )
            position_of_exist = np.where(is_exits is True)[0].tolist()

            if not position_of_exist:
                cluster_set.append({head,tail})

            elif len(position_of_exist) == 1:
                cluster_set[position_of_exist[0]].update([tail])

            else:
                del_element = []
                for i in position_of_exist[1:]:
                    cluster_set[position_of_exist[0]].update(cluster_set[i])
                    del_element.append(cluster_set[i])

                cluster_set[position_of_exist[0]].update([tail])

                for element in del_element:
                    cluster_set.remove(element)

        cluster_set = [list(i) for i in cluster_set]
        cluster_table = pd.DataFrame({self.index_col:cluster_set}).reset_index()
        cluster_table = cluster_table.rename(columns = {'index':'cluster'})
        cluster_table = cluster_table.explode(self.index_col)

        data_idx = pd.DataFrame(self.index_values,columns = [self.index_col])
        data_idx = data_idx.merge(cluster_table, how = 'left', on = 'id')
        data_idx.loc[data_idx['cluster'].isnull(), 'cluster'] = self.noise_value
        data_idx['cluster'] = data_idx['cluster'].astype(int)
        self.data_idx = data_idx

    def predict(self, input_embeddings:str = None):

        if input_embeddings is None:
            return self.data_idx['cluster'].tolist()

        if input_embeddings is not None:
            input_col = 'input_index'
            input_idx = pd.DataFrame({input_col:range(len(input_embeddings))})
            similarity_table = self._convert_to_similarity_pairs(
                self.embeddings,
                input_embeddings,
                threshold = self.threshold,
                output_head_name = self.index_col,
                output_tail_name = input_col
            )

            similarity_table = similarity_table.merge(
                self.data_idx, how = 'left', on = self.index_col
            )

            similarity_table = similarity_table[
                similarity_table.groupby(input_col)['value'].rank(method='first') == 1
            ]

            input_idx = input_idx.merge(similarity_table, how = 'left', on = input_col)
            input_idx.loc[input_idx['cluster'].isnull(), 'cluster'] = self.noise_value
            input_idx['cluster'] = input_idx['cluster'].astype(int)

            return input_idx['cluster'].tolist()

        return None

if __name__ == '__main__':
    from sentence_transformers import SentenceTransformer
    words = ['交易','交易市場','天氣','下雨','金融','風險','詐貸','你好','銀行','銀行','信用卡','風險']
    data = pd.DataFrame({'id':range(len(words)), 'event':words})

    model = SentenceTransformer('/Users/mac/Desktop/distiluse-base-multilingual-cased-v1')
    embeddings = model.encode(data['event'].tolist(), show_progress_bar = True)
    data['embeddings'] = embeddings.tolist()


    EC = SimilarityCulstering()
    EC.set_data(data, index_col='id', embedding_col= 'embeddings')
    EC.fit(0.6)
    result = EC.transform(
        data,
        index_col = 'id',
        embedding_col = 'embeddings',
        cluster_col = 'CLUSTER',
        cluster_name = 'word'
    )
