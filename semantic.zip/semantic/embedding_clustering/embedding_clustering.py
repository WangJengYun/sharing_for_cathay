import inspect
import pandas as pd 
import numpy as np 
from . import method

class EmbeddingClustering:
    def __init__(self, method_name):

        self.ec_module = None
        if hasattr(method, method_name):
            self.ec_module = getattr(method, method_name)
        else:
            raise ValueError(f'{method_name} is not found in method_name')

        self.ec_module = self.ec_module()

    @staticmethod
    def _get_params(module, input_args, ignore_worng_params = True):

        init_signature = inspect.signature(module)

        module_params = [
            p.name
            for p in init_signature.parameters.values()
            if p.name != "self"and p.kind != p.VAR_KEYWORD
        ]
        if not ignore_worng_params:

            wrong_params = [ p for p in input_args.keys() if p not in module_params]
            if wrong_params:
                # warnings.warn('Find wrong_params {}'.format('|'.join(wrong_params)))
                print('Find wrong_params {}'.format('|'.join(wrong_params)))

        input_params = {p : input_args[p] for p in module_params if p in input_args.keys()}
        return input_params

    def set_data(
        self,
        data:pd.DataFrame,
        index_col:str,
        embedding_col:str
    ):
        self.ec_module.set_data(data, index_col, embedding_col)

    def fit(self, **arg):
        input_params = self._get_params(self.ec_module.fit, arg, ignore_worng_params = False)
        self.ec_module.fit(**input_params)

    def predict(self, input_embeddings = None):
        return self.ec_module.predict(input_embeddings)
    
    def transform(
        self,
        data:pd.DataFrame,
        index_col:str,
        embedding_col:str,
        cluster_col:str = None,
        cluster_name:str = None,
        center_info:bool = False
    ):
        return self.ec_module.transform(
            data = data,
            index_col = index_col,
            embedding_col = embedding_col,
            cluster_col = cluster_col,
            cluster_name = cluster_name,
            center_info = center_info
        )

if __name__ == '__main__':
    from sentence_transformers import SentenceTransformer
    words = ['交易','交易市場','天氣','下雨','金融','風險','詐貸','你好','銀行','銀行','信用卡','風險']
    data = pd.DataFrame({'id':range(len(words)), 'event':words})

    model = SentenceTransformer('/Users/mac/Desktop/distiluse-base-multilingual-cased-v1')
    embeddings = model.encode(data['event'].tolist(), show_progress_bar = True)
    data['embeddings'] = embeddings.tolist()

    EC = EmbeddingClustering(method_name = 'BirchModel')
    EC.set_data(data, index_col='id', embedding_col= 'embeddings')
    EC.fit(threshold = 0.6)
    result = EC.transform(
        data,
        index_col = 'id',
        embedding_col = 'embeddings',
        cluster_col = 'cluster',
        cluster_name = 'word',
        center_info = True
    )
